
public class Pythagorean {
    public static void main(String[] args) {
        
        double legA = 4;
    	double legB = 5;

    		double hypotenuse = Math.sqrt((legA*legA) + (legB*legB));

    		System.out.println(hypotenuse);

    
        
        
    }
    

}