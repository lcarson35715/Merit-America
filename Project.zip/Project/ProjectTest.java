public class ProjectTest {
    public static void main(String[] args){
        
        Project project = new Project();
        Project project2 = new Project("Second Project");
        Project project3 = new Project("Third Project", "This is the project's description.");
        

        


        project.setName("My first project ever!");
        project.setDescription("This is an awesome description.");
       

        
    }
}