
public class StringManipulator
{
    
    public String trimAndConcat(String str1, String str2)
    {
       String concatStr="";
       concatStr+=str1.trim()+str2.trim();
       return concatStr;
    }

   
    public static void main (String[] args)
    {
       StringManipulator strManipulator = new StringManipulator();
       System.out.println(strManipulator.trimAndConcat("    Hello   "," World   "));
        
    }
}
 

   public class getIndexOrNull{

    
    String getIndexOrNull = new getIndexOrNull(String, string[int]);
    
    String str1 = "Coding";
    String str2 = "Hello World";
    String Str3 = "Hi";
    
    int a = 4;
    int b = 4;
    int c = 4;
    
    char letter = 'o';
    
    a = getIndexOrNull(str1, a);

    b = getIndexOrNull("Hello World", b);

    c = getIndexOrNull("Hi", c);

    System.out.println(a); 

    System.out.println(b); 

    System.out.println(c); 
}
