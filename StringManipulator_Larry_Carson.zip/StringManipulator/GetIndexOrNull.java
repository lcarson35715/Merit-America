/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package getindexornull;


/**
 *
 * @author User
 */
public class GetIndexOrNull {

public class getIndexOrNull{
    
    

    
    String getIndexOrNull, string(int));
    
    String str1 = "Coding";
    String str2 = "Hello World";
    String Str3 = "Hi";
    
    int a = 4;
    int b = 4;
    int c = 4;
    
    char letter = 'o';
    
    a = getIndexOrNull(str1, a);

    b = getIndexOrNull(str2, b);

    c = getIndexOrNull(str3, c);

        public getIndexOrNull() {
            this.getIndexOrNull = (String;
        }

    System.out.println(a); 

    System.out.println(b); 

    System.out.println(c); 
    
        // TODO code application logic here
    }
    
}
