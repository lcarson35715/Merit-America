
public class GorillaTest {
	public static void main(String[] args) {
		Gorilla Koko = new Gorilla();
		
		Koko.throwSomething();
		Koko.throwSomething();
		Koko.throwSomething();
		Koko.eatBananas();
		Koko.eatBananas();
		Koko.climb();
		Koko.displayEnergy();
	}
}
