
public class Bat {
	private int energyLevel;
	public Bat () {
		this.energyLevel = 300;
	}
	public void setEnergyLevel(int newLev) {
		energyLevel = newLev;
	}
	public int getEnergyLevel() {
		return energyLevel;
	}
	public int displayEnergy() {
		int level = this.getEnergyLevel();
		System.out.println(level);
		return level;
	}
	public void fly() {
		System.out.println("Flap");
		int dEL = this.getEnergyLevel();
		this.setEnergyLevel(dEL-50);
	}
	public void eatHuman() {
		int dEL = this.getEnergyLevel();
		this.setEnergyLevel(dEL+25);
	}
	public void attackTown() {
		System.out.println("Aaaaaah");
		int dEL = this.getEnergyLevel();
		this.setEnergyLevel(dEL-100);
	}
}
