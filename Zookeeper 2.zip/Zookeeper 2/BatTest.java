
public class BatTest {
	public static void main(String[] args) {
		Bat Dracula = new Bat();
		
		Dracula.attackTown();
		Dracula.eatHuman();
		Dracula.fly();
		Dracula.displayEnergy();
	}
}
